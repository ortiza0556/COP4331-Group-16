package core;

public class constants {

    public static final String NO_IMAGE_URL="images/noPoster";
    public static final String KEY="&apikey=3cfe9444";
}

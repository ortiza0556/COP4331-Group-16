package core;

import UI.GystUI;

public class GetYourShitTogether {

    public static void main(String[] args) {
        new GystUI();
    }
}
